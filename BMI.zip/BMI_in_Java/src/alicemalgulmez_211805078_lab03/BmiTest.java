package alicemalgulmez_211805078_lab03;

import java.util.Scanner;
public class BmiTest {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String[] pred=new String[3];
		Bmi bmi = new Bmi();
		Bmi[] input= new Bmi[3];
		int k;

		for(k=0;k<3;k++){
			System.out.println("----ENTER THE PERSON "+(k+1)+" 'S INFORMATION----");
			System.out.println("Enter the name, age, weight, height: ");
			input[k]=(new Bmi(scan.next(),scan.nextInt(),scan.nextDouble(),scan.nextDouble()));
			double x = Bmi.getBMI(input[k].getWeight(), input[k].getHeight());
			pred[k]= Bmi.getStatus(x);
		}
	
		for (Bmi person : input) {
		    System.out.println("The BMI result for " + person.getName() + " ( Age: " + person.getAge() + " Weight: " + person.getWeight() + " Height: " + person.getHeight() + ") is explained below.");
		}
	
		for(k=0;k<pred.length;k++) {
			System.out.println((k+1)+" is "+pred[k]);
		}
	}
}


