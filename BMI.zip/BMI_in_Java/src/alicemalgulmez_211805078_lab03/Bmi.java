package alicemalgulmez_211805078_lab03;

public class Bmi {
	private String name;
    private int age;
    private double weight;
    private double height;
    public static final double KILOGRAMS_PER_POUND =0.45359237;
    public static final double METERS_PER_INCH=0.0254;
	
    
    public Bmi(String name,double weight,double height){
        setName(name);
        setHeight(height);
        setWeight(weight);
        setAge(20);        
    }
    public Bmi(String name,int age,double weight,double height){
        setName(name);
        setAge(age);
        setWeight(weight);
        setHeight(height);      
    }

    public Bmi(){
        setName("John Black");
        setAge(25);
        setWeight(100);
        setHeight(50);        
    }
        
    public String getName() {
        return name;
    }
    public void setName(String Name) {
        name = Name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int Age) {
        age = Age;
    }
    public double getWeight() {
        return weight;
    }
    public void setWeight(double Weight) {
        weight = Weight;
    }
    public double getHeight() {
        return height;
    }
    public void setHeight(double Height) {
        height = Height;
    }
    public static double getBMI(double weight,double height){
        return  (weight*(KILOGRAMS_PER_POUND))/((height*(METERS_PER_INCH))*(height*(METERS_PER_INCH)));
    }
    
    
    public static String getStatus(double bmi){
        if (bmi<18.5){
            return "Underweight";
        }
        else if (bmi>=18.5 && bmi<25){
            return "Normal";
        }
        else if (bmi>=25 && bmi<30){
            return "Overweight";
        }
        else{
            return "Obese";
        }
    }
}